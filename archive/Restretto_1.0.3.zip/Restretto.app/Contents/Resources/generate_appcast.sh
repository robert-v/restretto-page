#!/bin/sh

#  generate_appcast.sh
#  ProcessSpy
#
#  Created by Robert Varga on 09/02/2024.
#  

/Users/robertvarga/Library/Developer/Xcode/DerivedData/Restretto-ezctgylrrccihhanbtbyfiovghag/SourcePackages/artifacts/sparkle/Sparkle/bin/generate_appcast --full-release-notes-url https://restretto.app/archive/release_notes.html ../Archive
